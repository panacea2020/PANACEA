class Config(object):
    SECRET_KEY = 'this-is-a-shitty-secret-key'
